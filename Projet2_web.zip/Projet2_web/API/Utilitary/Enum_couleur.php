<?php
class Enum_couleur
{
    const ROUGE = 'rouge';
    const VERT = 'vert';
    const BLEU = 'bleu';
    const JAUNE = 'jaune';
    const ORANGE = 'orange';
    const VIOLET = 'violet';
}

// Vous pouvez utiliser les valeurs de l'énumération de cette manière :
// $selectedColor = Enum_couleur::VERT;

// if ($selectedColor === Enum_couleur::ROUGE) {
//     echo "La couleur sélectionnée est Rouge.";
// } elseif ($selectedColor === Enum_couleur::VERT) {
//     echo "La couleur sélectionnée est vert.";
// } elseif ($selectedColor === Enum_couleur::BLEU) {
//     echo "La couleur sélectionnée est bleu.";
// } else {
//     echo "La couleur sélectionnée n'est pas reconnue.";
// }
?>
