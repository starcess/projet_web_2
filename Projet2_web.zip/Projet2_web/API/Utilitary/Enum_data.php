<?php
class Enum_data
{
    const CHEMISE = 'chemise';
    const CRAVATTE = 'cravatte';
    
}
?>