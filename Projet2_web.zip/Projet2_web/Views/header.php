<header>
    <?php include('navigation.php'); ?>
</header>